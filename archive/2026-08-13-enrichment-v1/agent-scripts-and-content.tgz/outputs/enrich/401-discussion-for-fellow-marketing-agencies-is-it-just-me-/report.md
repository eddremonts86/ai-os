# 401 Discussion for fellow marketing agencies: Is it just me or is B2B SaaS client no-show rate way up right now?

sections filled: 13

sections left as TODO: 0

frontmatter changed: status draft -> enriched

check after enrichment:
```

ai-os plans check — 1 plan

  web-ready: 1/1 (100%)

  status: enriched=1 


```
