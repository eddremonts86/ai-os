# 347 [Co-Founder Wanted] Non-Technical Founder looking for Full-Stack Developer to build an AI-driven Gadget Recommendation Platform (Equity/Co-Founder)

sections filled: 13

sections left as TODO: 0

frontmatter changed: status draft -> enriched

check after enrichment:
```

ai-os plans check — 1 plan

  web-ready: 1/1 (100%)

  status: enriched=1 


```
