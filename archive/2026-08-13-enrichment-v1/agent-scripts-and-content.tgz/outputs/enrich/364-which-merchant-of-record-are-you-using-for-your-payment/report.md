# 364 Which Merchant of Record are you using for your payments?

sections filled: 13

sections left as TODO: 0

frontmatter changed: status draft -> enriched

check after enrichment:
```

ai-os plans check — 1 plan

  web-ready: 1/1 (100%)

  status: enriched=1 


```
