# 387 Ran a SaaS's organic social for 8 weeks. The ai poster maker content flopped, raw phone clips carried it

sections filled: 13

sections left as TODO: 0

frontmatter changed: status draft -> enriched

check after enrichment:
```

ai-os plans check — 1 plan

  web-ready: 1/1 (100%)

  status: enriched=1 


```
