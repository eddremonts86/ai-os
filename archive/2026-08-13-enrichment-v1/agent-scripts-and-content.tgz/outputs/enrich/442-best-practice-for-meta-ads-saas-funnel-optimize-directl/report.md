# 442 Best practice for Meta Ads SaaS funnel: Optimize directly for Free Trial or use secondary micro-conversions?

sections filled: 13

sections left as TODO: 0

frontmatter changed: status draft -> enriched

check after enrichment:
```

ai-os plans check — 1 plan

  web-ready: 1/1 (100%)

  status: enriched=1 


```
