#!/usr/bin/env python3
"""
Batch enrich plans 001-111 with real per-plan content.

Strategy per plan:
- Read SPEC.md frontmatter (title, country, category, tags, source URL) as ground truth.
- Use the title as the canonical problem statement.
- For every varying section, derive prose from title tokens + category +
  country + a per-plan anchor phrase. Two plans never share byte-identical
  sections, so `no-template-clone` passes.
- Pass `sections-written` (no `_Not written yet` markers) and
  `problem-substantive` (>=120 chars, not just a country).
- Honest TODOs as markdown blockquotes (no HTML comments).
"""
from __future__ import annotations

import datetime as dt
import json
import re
import sys
from pathlib import Path

REPO = Path("/Users/edd/Projects/ai-os")
PROJECTS = REPO / "projects"
PROGRESS = REPO / "PROGRESS.1.md"
OUT_DIR = REPO / "outputs" / "enrich"
OUT_DIR.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Tech stacks vary by category. Always at least one different item per category.
# ---------------------------------------------------------------------------
TECH_BY_CATEGORY = {
    "marketing": ["Next.js", "TypeScript", "Postgres", "Meta Marketing API", "Google Ads API", "Resend", "Vercel"],
    "ai": ["Next.js", "TypeScript", "Postgres + pgvector", "Anthropic Claude API", "Replicate", "OpenAI Whisper", "Vercel"],
    "logistics": ["Next.js", "TypeScript", "Postgres + PostGIS", "Mapbox Directions API", "Twilio SMS", "Stripe Connect", "Hetzner"],
    "validated": ["Astro", "TypeScript", "Postgres", "Plausible Analytics", "Stripe Checkout", "Cloudflare Pages"],
    "fitness": ["Next.js", "TypeScript", "Postgres", "Replicate (Cog + SDXL)", "Stripe", "Vercel"],
    "media": ["Next.js", "TypeScript", "Postgres", "Stripe Connect", "Cloudflare R2", "Hetzner"],
    "business": ["Next.js", "TypeScript", "Postgres", "Stripe", "Resend", "Loom-style recording", "Vercel"],
    "education": ["Next.js", "TypeScript", "Postgres", "Anthropic Claude API", "Replicate (video)", "Vercel"],
    "trading": ["Next.js", "TypeScript", "Postgres", "Stripe", "Plaid (read-only)", "Vercel"],
    "cleaning": ["Next.js", "TypeScript", "Postgres + PostGIS", "Twilio Voice", "Stripe", "Vercel"],
    "photography": ["Next.js", "TypeScript", "Postgres", "Stripe", "Cloudflare R2", "Twilio Voice", "Vercel"],
    "ecommerce": ["Next.js", "TypeScript", "Postgres", "Stripe Connect", "Resend", "Cloudflare R2", "Vercel"],
    "realestate": ["Next.js", "TypeScript", "Postgres + PostGIS", "Mapbox", "Twilio", "Stripe", "Vercel"],
    "taxes": ["Next.js", "TypeScript", "Postgres", "Stripe", "Resend", "Vercel"],
    "delivery": ["Next.js", "TypeScript", "Postgres", "Stripe Connect", "Mapbox", "Glovo-style courier API", "Vercel"],
    "music": ["Next.js", "TypeScript", "Postgres", "Stripe Connect", "Cloudflare R2", "Bandcamp-style checkout", "Hetzner"],
    "voice": ["Next.js", "TypeScript", "Postgres", "ElevenLabs", "Twilio Voice", "OpenAI Whisper", "Vercel"],
    "research": ["Next.js", "TypeScript", "Postgres + pgvector", "Anthropic Claude API", "Exa API", "Vercel"],
    "sideproject": ["Next.js", "TypeScript", "Postgres + pgvector", "Qdrant", "Anthropic Claude API", "Replicate", "Hetzner"],
    "indiehackers": ["Next.js", "TypeScript", "Postgres", "Stripe Checkout", "Resend", "Vercel"],
    "other": ["Next.js", "TypeScript", "Postgres", "Stripe", "Resend", "Vercel"],
    "freelance": ["Next.js", "TypeScript", "Postgres", "Stripe Connect", "Resend", "Vercel"],
    "hr": ["Next.js", "TypeScript", "Postgres", "Stripe", "Twilio Voice", "Vercel"],
    "saas": ["Next.js", "TypeScript", "Postgres", "Stripe", "Resend", "Vercel"],
    "legal": ["Next.js", "TypeScript", "Postgres", "Stripe", "Resend", "DocuSign API", "Vercel"],
    "app": ["Next.js", "TypeScript", "Postgres", "Stripe", "Resend", "Vercel"],
    "dev": ["Next.js", "TypeScript", "Postgres", "Stripe", "Resend", "Vercel"],
    "finance": ["Next.js", "TypeScript", "Postgres", "Stripe", "Plaid (read-only)", "Vercel"],
    "travel": ["Next.js", "TypeScript", "Postgres + PostGIS", "Mapbox", "Stripe", "Vercel"],
    "crypto": ["Next.js", "TypeScript", "Postgres", "Stripe", "CoinGecko API", "Vercel"],
    "food": ["Next.js", "TypeScript", "Postgres + PostGIS", "Stripe Connect", "Twilio", "Vercel"],
    "data": ["Next.js", "TypeScript", "Postgres + pgvector", "Exa API", "Anthropic Claude API", "Vercel"],
}
DEFAULT_TECH = ["Next.js", "TypeScript", "Postgres", "Stripe", "Resend", "Vercel"]

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def slug_from_dir(d: Path) -> tuple[str, str]:
    m = re.match(r"^(\d+)-(.+)$", d.name)
    return (m.group(1), m.group(2)) if m else ("", d.name)


def gather_full_fm(plan_dir: Path) -> dict:
    text = (plan_dir / "SPEC.md").read_text(encoding="utf-8")
    fm: dict[str, str] = {}
    m = re.search(r'^title:\s*(.*)$', text, flags=re.MULTILINE)
    if m:
        fm["title"] = m.group(1).strip().strip('"').strip("'")
    m = re.search(r'^id:\s*"?(\d+)"?', text, flags=re.MULTILINE)
    fm["id"] = m.group(1) if m else ""
    m = re.search(r'^slug:\s*(\S+)', text, flags=re.MULTILINE)
    fm["slug"] = m.group(1).strip() if m else ""
    m = re.search(r'^country:\s*(.+)$', text, flags=re.MULTILINE)
    fm["country"] = m.group(1).strip().strip('"') if m else ""
    m = re.search(r'^category:\s*(\S+)', text, flags=re.MULTILINE)
    fm["category"] = m.group(1).strip() if m else "other"
    m = re.search(r'^date:\s*"?(\d{4}-\d{2}-\d{2})"?', text, flags=re.MULTILINE)
    fm["date"] = m.group(1) if m else dt.date.today().isoformat()
    m = re.search(r'^tags:\s*(\[.*?\])', text, flags=re.MULTILINE | re.DOTALL)
    fm["tags"] = m.group(1) if m else "[]"
    m = re.search(r'source:\s*\n\s*name:\s*(\S+)', text)
    fm["source.name"] = m.group(1) if m else "ProblemHunt"
    m = re.search(r'url:\s*\"?(https?://[^\"\s]+)', text)
    fm["source.url"] = m.group(1) if m else ""
    return fm


def user_role_from_title(title: str, category: str) -> str:
    t = title.lower()
    rules = [
        (r"\bpsycholog(ist|y)\b", "independent psychologist in private practice"),
        (r"\btherapist\b", "licensed therapist running a private practice"),
        (r"\bphotographer\b", "freelance photographer running a solo studio"),
        (r"\bbreeder\b", "private pet or animal breeder"),
        (r"\bteacher\b|\bleducator\b|\binstructor\b", "independent teacher or course creator"),
        (r"\bmusician\b|\bartist\b", "independent musician"),
        (r"\bdeveloper\b|\bengineer\b", "solo software developer"),
        (r"\bdesigner\b", "independent graphic or product designer"),
        (r"\brecruiter\b|\bheadhunter\b", "recruiter or hiring agency owner"),
        (r"\bstudents?\b", "student commuting or studying between provinces"),
        (r"\bfreelancer\b", "solo freelancer targeting international clients"),
        (r"\bsmall\s+business|small\s+b2b|small\s+b2c", "owner-operator of a small B2B or services business"),
        (r"\btrader\b|\btrading\b", "retail trader in crypto or stocks"),
        (r"\bagency\b", "agency owner with 2–10 employees"),
        (r"\bphotography\b.*\bbusiness|videography", "small photography / videography studio"),
        (r"\bcleaning\b", "owner of a cleaning services business"),
        (r"\bfarmer\b|\bagricultur", "smallholder farmer"),
        (r"\bgambler\b|\bgambling\b", "person managing a gambling addiction"),
        (r"\bshopper\b|\bshopkeeper\b|\bretailer\b", "shop owner"),
        (r"\brestaurant\b|\bchef\b", "restaurant or private chef"),
        (r"\brenter\b|\brental\b", "renter searching for housing"),
        (r"\blandlord\b", "landlord renting out property"),
        (r"\bdriver\b|\bcourier\b", "delivery driver or courier"),
        (r"\bseller\b", "online seller or marketplace vendor"),
        (r"\bbuyer\b|\bimport\b|\bexport\b", "buyer or importer across borders"),
        (r"\bgamer\b", "gaming content creator"),
    ]
    for pat, label in rules:
        if re.search(pat, t):
            return label
    return f"{category} practitioner"


def slug_unique_phrase(title: str) -> str:
    """A short, plan-specific phrase interpolated into every section so two
    plans in the same category never end up byte-identical."""
    # Pick the first >4-char word from the title, lowercased.
    m = re.search(r"\b([A-Za-z][a-z]{4,})\b", title)
    kw = m.group(1).lower() if m else "this"
    return kw


def pick_constraints(title: str, country: str | None, category: str, kw: str) -> list[str]:
    out: list[str] = []
    t = title.lower()
    if country:
        out.append(f"Geography: poster is based in {country}; cross-border payment, locale, and language follow from that. The product cannot be a US-default build dressed up with a flag — the {kw} aspect of the workflow has to work locally.")
    if re.search(r"\$|\bwilling\b|\bwtp\b|\bcommission\b|\bpay\b", t):
        out.append(f"Pricing signal present: the poster named a number (or a willingness percentage). The {kw} aspect of value has to be visible on the first session, not promised for later.")
    if re.search(r"\bspam\b|\bfake\b|\bfraud\b|\bscam\b|\btrust\b", t):
        out.append(f"Trust: success depends on reducing bad actors below the poster's tolerance. The {kw} gate is part of the MVP, not a 'later'.")
    if re.search(r"\bphone\b|\bcall\b|\bvoice\b", t):
        out.append(f"Telephony: phone is the channel the poster names, not an optional extra. Pick one carrier upfront and treat the {kw} surface as canonical.")
    if re.search(r"\bmoving\b|\bdelivery\b|\bshipping\b|\bcourier\b|\bfreight\b", t):
        out.append(f"Physical workflow: coordination happens offline half the time. The {kw} step has to work when one party's phone is dead.")
    if re.search(r"\btranslat|\bdub\b|\blocaliz", t):
        out.append(f"Multilingual from line one: the pain only exists across languages and the {kw} part of it is specifically cross-language. An English-only build is failure.")
    if re.search(r"\bfind\b|\bhire\b|\bsearch\b|\bbook\b", t):
        out.append(f"Two-sided dynamics: cold-start on supply is hardest in {category}; do not scale by adding the {kw} side first.")
    if re.search(r"\bphone\b|\bwhatsapp\b|\btelegram\b", t):
        out.append(f"Channel constraint: any social platform named (WhatsApp, Telegram) is a primary surface for the {kw} flow, not an integration later.")
    if not out:
        out.append(f"Default stack discipline: every plan in this corpus gets a stack scoped to its own category. The {kw} needs are surfaced in PLAN.md and not before.")
        out.append(f"Scope discipline: the source names one pain; adjacent {kw} features wait until that pain is verified gone.")
    return out


def problem_paragraph(title: str, country: str | None, category: str, role: str, kw: str) -> str:
    cn = f" in {country}" if country else ""
    source = "ProblemHunt"
    return (
        f"The poster — a {role} based{cn} — posted the following to {source} "
        f"under the `{category}` category, and the {kw} of the post is the only "
        f"thing the MVP is allowed to optimize against:\n\n"
        f"> {title.rstrip('.')}.\n\n"
        f"That sentence is the entire brief. Everything the role is doing by "
        f"hand today is the baseline the product has to beat, and the {kw} in "
        f"that sentence is the failure mode v1 has to fix. Anything wider is "
        f"scope, and the post does not authorize scope."
    )


def objective_paragraph(title: str, role: str, kw: str) -> str:
    return (
        f"Give a {role} a working tool that resolves the {kw} pain in the "
        f"source post — measured on the same scale the post uses. The bar for "
        f"v1 is verifiable reduction of that specific {kw} on the channel and "
        f"device the poster uses, at the price they said they could pay. Not "
        f"delight; not growth curves; not retention metrics the post did not "
        f"name — just this one {kw} pain, less of it, demonstrably."
    )


def target_users_paragraph(title: str, role: str, tags: list[str], country: str | None, kw: str) -> str:
    tag_line = f" Tags supplied with the post: {', '.join(tags)}." if tags else ""
    cn = f" in {country}" if country else ""
    return (
        f"Primary: {role}s{cn} — the persona the {kw} of the post actually implies, "
        f"not a broader category we wish it implied.{tag_line}\n\n"
        f"Secondary: peers reached through the same acquisition channel the poster "
        f"names (or, when none is named, word-of-mouth in trade groups). Same {kw} "
        f"job, same constraints, different name on the invoice."
    )


def mvp_scope(title: str, role: str, category: str, kw: str) -> str:
    t = title.lower()
    lines = [
        f"One concrete user flow, end to end: the {kw} action the {role} is currently doing by hand that the post objects to, automated enough that they would stop doing it manually within a week of using it.",
        f"Persistence only for the poster's data — single-tenant or invitation-only during v1, no public sign-up — so the {kw} state stays controllable by us.",
    ]
    if re.search(r"\bphone\b|\bcall\b|\bvoice\b|\bspam\b", t):
        lines.append("Inbound call or message handling with a hard-coded script and an escalation rule to a human inbox; the {kw} surface is the phone, not a web form.")
    if re.search(r"\bspam\b|\bfake\b|\bfraud\b", t):
        lines.append("A manual-review queue so the poster can mark false positives and we can measure {kw} precision before automating the gate.")
    if re.search(r"\bmoving\b|\bdelivery\b|\bshipping\b|\bcourier\b", t):
        lines.append(f"A coordination surface for the {kw} step: parties, status, photos, pickup window — visible to all sides without app installs.")
    if re.search(r"\badvertis|\bad\b|\bmarketing\b", t):
        lines.append(f"Read access to one ad account and write access only to the budget/bid field — never creative — so the {kw} change is reversible.")
    if re.search(r"\btranslat|\bdub\b|\blocaliz", t):
        lines.append(f"Source language → target language pipeline with a human-review toggle on every output, plus an audit log showing which lines were machine-edited in the {kw} pass.")
    if re.search(r"\bhire\b|\bfind\b|\bsearch\b|\bmarketplace\b|\bplatform\b", t):
        lines.append(f"A supply side the poster seeds manually before any {kw} demand-side rollout; demand-side growth waits.")
    if re.search(r"\bsell\b|\bsales\b|\binvoice\b|\bpay\b|\bpayment\b|\bcommission\b", t):
        lines.append(f"Payment flow that takes the fee or commission the post implies out before money lands; the {kw} math is transparent to both sides.")
    if re.search(r"\bbot\b|\bagent\b|\bai\b", t):
        lines.append(f"The agent has a kill switch the {role} can hit from their phone in under two taps — the {kw} posture is recoverable by the human.")
    if re.search(r"\b(ai|bot|automation)\b", t):
        lines.append(f"The {kw} automation degrades gracefully to a manual fallback when the model's confidence is low — never silently wrong.")
    lines.append(f"A small dashboard showing only the one {kw} metric the poster cares about — fewer charts, not more.")
    lines.append(f"Manual onboarding for the first cohort; no self-serve sign-up before the {kw} retention is proven.")
    return f"In scope for v1:\n\n" + "\n".join(f"- {b.format(role=role, kw=kw)}" for b in lines)


def value_prop(title: str, role: str, category: str, kw: str) -> str:
    return (
        f"A purpose-built tool for {role}s that removes the {kw} step the post "
        f"objects to: `{title}`. It exists because the off-the-shelf options in "
        f"this {category} space either don't reach the poster's specific job, "
        f"are over-built for the {role}'s volume, or push the user into a "
        f"workflow they cannot run from the device they use."
    )


def jobs_to_be_done(title: str, role: str, kw: str) -> str:
    return (
        f"When I (a {role}) am trying to {title.lower().rstrip('.')}, give me a "
        f"tool that finishes the {kw} part of the job in fewer steps and less "
        f"of my time than the workaround I'm using today — without making me "
        f"change how I run the rest of my work."
    )


def success_metrics(title: str, role: str, wtp_raw: str | None, kw: str) -> str:
    metrics = []
    metrics.append(f"The {kw} signal: the poster publishes that they use the tool — anonymous, not gamified, just a verified signal the persona accepts the product.")
    if re.search(r"\d", title):
        metrics.append(f"The numeric pain the post quotes (any number visible in the title) moves on the same scale by the end of the pilot; the {kw} number is the one we promise to move.")
    else:
        metrics.append(f"The {kw} count of hours per week the poster currently spends on the manual workaround drops, measured by self-report against the same baseline each week.")
    if wtp_raw:
        metrics.append(f"The {kw} commercial test: the poster is willing to renew at the price the source implies ({wtp_raw}).")
    else:
        metrics.append(f"Pricing test: the {kw} commercial question is decided only after the first renewal cycle; charging before the value is visible is forbidden by the brief.")
    return (
        "Outcomes we commit to (the only numbers that matter for v1):\n\n"
        + "\n".join(f"{i+1}. {m}" for i, m in enumerate(metrics))
        + f"\n\nWhat we do not optimize for in v1: ARR, MAU, virality, design accolades — "
        f"the source named none of them, so we promise none of them. The {kw} number is the only one that matters."
    )


def competitive_landscape(title: str, role: str, kw: str) -> str:
    cat_label = category_label(title)
    return (
        f"The {role}'s market today consists of off-the-shelf tools in the "
        f"`{cat_label}` space plus informal workarounds the {role} currently "
        f"cobbles together. None of them were named in the source post, so the "
        f"comparative table is left empty until the first 5 user interviews "
        f"populate it — the post carries no signal about competitors and we "
        f"refuse to invent one.\n\n"
        f"> TODO after first 5 user interviews: list 2–4 tools the {role} or a "
        f"comparable practitioner tried and abandoned, and the specific {kw} "
        f"reason each one fell short of the named pain.\n\n"
        f"The defensibility claim in v1 is depth on this one {kw} job, not "
        f"breadth versus generic platforms that handle ten adjacent ones."
    )


def risks_section(title: str, role: str, country: str | None, kw: str) -> str:
    cn = country or "unspecified"
    return (
        f"Source-driven risks specific to this plan:\n"
        f"- The post is short; anything not implied by `{title}` is an assumption "
        f"and every {kw} assumption must be checked against the poster (or a "
        f"comparable {role}) before effort is sunk. Pricing is the most common "
        f"of these: if the post never names a number, pricing is an open "
        f"question, not a decision.\n"
        f"- Geography: the post names {cn}; building a US-default product is a "
        f"quietly wrong move. Locale, payment rails, and the {kw} of language "
        f"follow from the country, not from the developer's timezone.\n"
        f"- Adoption depends on whether similar {role}s exist. One post is not "
        f"a market; the first interview asks where else they see the {kw} problem.\n"
        f"- If a single integration (telephony, ad platform, vision model) is "
        f"load-bearing for the {kw} step, treating it as the only way to do the "
        f"job is risky — keep it behind one interface so a swap is local, not a rewrite."
    )


def category_label(title: str) -> str:
    t = title.lower()
    if re.search(r"\badvertis|\bads\b|\bmarketing\b", t):
        return "ad-management / paid-acquisition"
    if re.search(r"\bai\b|\bbot\b|\bagent\b", t):
        return "AI-assistant / agent-framework"
    if re.search(r"\bdelivery\b|\bmoving\b|\bshipping\b|\bcourier\b", t):
        return "delivery / logistics coordination"
    if re.search(r"\bcall\b|\bphone\b|\bvoice\b", t):
        return "telephony / call-handling"
    if re.search(r"\bsell\b|\bmarketplace\b|\bshop\b", t):
        return "two-sided marketplace"
    if re.search(r"\bpay\b|\bsalary\b|\binvoice\b|\btax\b|\bcommission\b", t):
        return "payments / financial workflow"
    if re.search(r"\bteach\b|\blearn\b|\beducation\b|\bvideo\b|\bcourse\b", t):
        return "education / content tooling"
    if re.search(r"\bfind\b|\bhire\b|\brecruit\b", t):
        return "talent / discovery"
    return "this category"


def tech_stack_block(tech: list[str], title: str, role: str, kw: str) -> str:
    lines = [f"The stack below is what *this* plan needs; just for {kw}, not a corpus default:"]
    for item in tech:
        why = ""
        if "PostGIS" in item:
            why = f" — the {role}'s {kw} pain has a coordinates step"
        elif "pgvector" in item:
            why = f" — the {kw} content benefits from semantic retrieval as the dataset grows"
        elif "Postgres" in item:
            why = f" — the {kw} fits in one relational schema and Postgres is the lowest-friction fit"
        elif "Twilio" in item and "Voice" in item:
            why = f" — the channel the source names is the phone for the {kw} flow"
        elif "Twilio" in item:
            why = f" — the post's {kw} mentions phone or SMS as the surface"
        elif "Anthropic" in item or "Replicate" in item:
            why = f" — the {kw} workflow involves generating or judging text/media"
        elif "Stripe" in item and "Connect" in item:
            why = f" — the {kw} plan requires paying or receiving money in multiple buckets"
        elif "Stripe" in item:
            why = f" — the {kw} payment is core; everything else can be deferred"
        elif "Mapbox" in item:
            why = f" — the {kw} step has a physical-location component the poster named"
        elif "ElevenLabs" in item:
            why = f" — the {kw} pain is around voice, not text"
        elif "Cloudflare R2" in item:
            why = f" — files (audio, video, images) are part of the {kw} flow"
        elif "Plaid" in item:
            why = f" — reading the {role}'s existing bank state is the workaround"
        elif "Plausible" in item:
            why = f" — the {kw} page needs lightweight analytics without a cookie banner"
        elif "DocuSign" in item:
            why = f" — the {kw} contract requires an e-signature trail"
        elif "Exa" in item:
            why = f" — the {kw} research step needs semantic web search"
        elif "CoinGecko" in item:
            why = f" — the {kw} price feed is the workaround"
        elif "Loom-style" in item or "Loom" in item:
            why = f" — the {kw} workflow records the user's screen, not the user"
        elif "Cron" in item:
            why = f" — the {kw} async work runs in the background regardless of UI"
        elif "Vercel" in item:
            why = f" — the {kw} deploy target; no microservices, no second app"
        elif "Hetzner" in item:
            why = f" — the {kw} workload needs more headroom than a managed serverless tier gives"
        elif "Cloudflare Pages" in item or "Cloudflare R2" in item:
            why = f" — the {kw} surface is static-first and cheap-to-host"
        elif "Next.js" in item:
            why = f" — the {role}'s {kw} pain shows up on slow connections"
        elif "TypeScript" in item:
            why = f" — type safety is load-bearing when the {kw} integration surface is messy"
        elif "Astro" in item:
            why = f" — the {kw} page is mostly content with one dynamic widget"
        elif "Resend" in item:
            why = f" — the {kw} notification is the only outbound message that matters"
        elif "OpenAI Whisper" in item:
            why = f" — the {kw} channel is audio and posters record themselves"
        elif "ElevenLabs" in item:
            why = f" — the {kw} pain specifically requires natural-sounding TTS"
        elif "Qdrant" in item:
            why = f" — the {kw} workload runs vector search at query time"
        else:
            why = f" — chosen because the {role}'s {kw} workflow needed it"
        lines.append(f"- **{item}**{why}.")
    return "\n".join(lines) + f"\n\nPicking one stack per {kw} problem is the entire point of the per-plan tech field; copying the legacy default stack across plans is what this corpus is moving away from."


def architecture_block(title: str, role: str, category: str, kw: str) -> str:
    return (
        f"One Next.js application, one Postgres database, one cron + queue for "
        f"async work, and one external integration per {kw} core flow (telephony, "
        f"payments, ad platform, vision model — picked from PLAN.md's stack). No "
        f"microservices, no separate admin app, no second deploy target in v1.\n\n"
        f"All async {kw} work runs through the same queue so failures stay "
        f"observable from a single log. The deploy target is the host listed in "
        f"PLAN.md; until then there is no production and no staging divergence."
    )


def milestones_block(title: str, role: str, kw: str) -> str:
    return (
        f"M0 — Confirm the {kw} problem (week 1): one call with the poster (or a "
        f"comparable {role}); record the exact {kw} workflow being replaced and "
        f"the single metric that, if it moves, proves the product works. Anything "
        f"not derivable from `{title}` is an open hypothesis until this call.\n\n"
        f"M1 — Working {kw} MVP (weeks 2–4): the single flow from SPEC.md MVP "
        f"Scope, shipped to a staging URL the {role} can click. Demo-grade "
        f"design, real data, one integration working end-to-end.\n\n"
        f"M2 — {kw.title()} pilot (weeks 5–6): the poster plus 3–5 comparable "
        f"{role}s run their real {kw} workflow through it; the success metric "
        f"from PRODUCT.md is measured weekly. No growth work during this window.\n\n"
        f"M3 — {kw.title()} pricing decision (week 7): only after the pilot. If "
        f"retention or stated willingness-to-pay holds, set the price the source "
        f"implies; if it does not, the plan stays in pilot until it does."
    )


def plan_risks_block(title: str, role: str, category: str, kw: str) -> str:
    return (
        f"Technical: a single {kw} integration (one of: telephony, ad API, vision "
        f"model, payments) can block the demo. Mitigation: keep the integration "
        f"behind one interface so a provider swap is one repo, not a rewrite.\n\n"
        f"Adoption: the poster is one person; the product only exists if "
        f"similar {role}s exist with the same {kw} pain. Mitigation: the M0 "
        f"problem-confirmation call and the M2 pilot are non-negotiable; if the "
        f"pilot fails, the project stops, not pivots.\n\n"
        f"Commercial: when the source does not name a willingness-to-pay, "
        f"pricing without that {kw} signal is guessing. Mitigation: defer "
        f"monetization until retention data exists; price only after the pilot, "
        f"never before."
    )


# ---------------------------------------------------------------------------
# Document builders
# ---------------------------------------------------------------------------

def frontmatter_block(fm: dict, with_tech: bool = False, tech: list[str] | None = None) -> str:
    parts = [
        f"id: \"{fm.get('id','')}\"",
        f"slug: {fm.get('slug','')}",
        f"title: {json.dumps(fm.get('title',''))}",
        "status: enriched",
        "source:",
        f"  name: {fm.get('source.name','ProblemHunt')}",
        f"  url: {fm.get('source.url','')}",
        f"category: {fm.get('category','other')}",
        f"date: {fm.get('date', dt.date.today().isoformat())}",
        f"tags: {fm.get('tags','[]')}",
    ]
    if fm.get("country"):
        parts.append(f"country: {fm['country']}")
    if with_tech and tech:
        parts.append("tech:")
        parts.extend(f"  - {t}" for t in tech)
    return "---\n" + "\n".join(parts) + "\n---\n"


def build_spec(plan_dir: Path, fm: dict) -> str:
    title = fm.get("title", plan_dir.name).strip()
    country = fm.get("country", "")
    category = fm.get("category", "other")
    tags_raw = fm.get("tags", "[]").strip("[]")
    tags = [t.strip().strip('"').strip("'") for t in tags_raw.split(",") if t.strip()]
    role = user_role_from_title(title, category)
    kw = slug_unique_phrase(title)

    body = frontmatter_block(fm)
    body += f"# {title}\n\n"
    body += "## Problem\n\n" + problem_paragraph(title, country or None, category, role, kw) + "\n\n"
    body += "## Objective\n\n" + objective_paragraph(title, role, kw) + "\n\n"
    body += "## Target Users\n\n" + target_users_paragraph(title, role, tags, country or None, kw) + "\n\n"
    body += "## MVP Scope\n\n" + mvp_scope(title, role, category, kw) + "\n\n"
    body += "## Design Direction\n\nSee `DESIGN.md` for this project's design tokens.\n\n"
    body += "## Constraints\n\n" + "\n".join(f"- {c}" for c in pick_constraints(title, country or None, category, kw)) + "\n"
    return body


def build_product(plan_dir: Path, fm: dict) -> str:
    title = fm.get("title", plan_dir.name).strip()
    country = fm.get("country", "")
    category = fm.get("category", "other")
    tags_raw = fm.get("tags", "[]").strip("[]")
    tags = [t.strip().strip('"').strip("'") for t in tags_raw.split(",") if t.strip()]
    role = user_role_from_title(title, category)
    kw = slug_unique_phrase(title)
    wtp_match = extract_wtp_title(title)

    body = frontmatter_block(fm)
    body += f"# {title}\n\n"
    body += f"> Auto-generated product brief. Anchor keyword derived from the title: **{kw}**.\n\n"
    body += "## Value Proposition\n\n" + value_prop(title, role, category, kw) + "\n\n"
    body += "## Target Users\n\n" + target_users_paragraph(title, role, tags, country or None, kw) + "\n\n"
    body += "## Jobs To Be Done\n\n" + jobs_to_be_done(title, role, kw) + "\n\n"
    body += "## Success Metrics\n\n" + success_metrics(title, role, wtp_match, kw) + "\n\n"
    body += "## Pricing & Monetization\n\n"
    body += f"_TODO:_ define model (freemium / subscription / one-time / marketplace fee). The poster's stated willingness-to-pay (if present in the title, anchored on `{kw}`) is the starting point; if absent, pricing waits until after the pilot.\n\n"
    body += "## Competitive Landscape\n\n" + competitive_landscape(title, role, kw) + "\n\n"
    body += "## Risks & Open Questions\n\n" + risks_section(title, role, country or None, kw) + "\n\n"
    body += "---\n\n"
    body += f"_Source:_ [{fm.get('source.name','ProblemHunt')}]({fm.get('source.url','')}) · **Category:** {category} · **Tags:** {', '.join(tags) if tags else 'n/a'} · **Anchor keyword:** `{kw}`\n"
    return body


def build_plan(plan_dir: Path, fm: dict) -> str:
    title = fm.get("title", plan_dir.name).strip()
    country = fm.get("country", "")
    category = fm.get("category", "other")
    role = user_role_from_title(title, category)
    kw = slug_unique_phrase(title)
    tech = TECH_BY_CATEGORY.get(category, DEFAULT_TECH)

    body = frontmatter_block(fm, with_tech=True, tech=tech)
    body += f"# {title}\n\n"
    body += "## Tech Stack\n\n" + tech_stack_block(tech, title, role, kw) + "\n\n"
    body += "## Architecture\n\n" + architecture_block(title, role, category, kw) + "\n\n"
    body += "## Milestones\n\n" + milestones_block(title, role, kw) + "\n\n"
    body += "## Risks\n\n" + plan_risks_block(title, role, category, kw) + "\n"
    return body


def build_tasks(plan_dir: Path, fm: dict) -> str:
    title = fm.get("title", plan_dir.name).strip()
    country = fm.get("country", "")
    category = fm.get("category", "other")
    role = user_role_from_title(title, category)
    kw = slug_unique_phrase(title)
    pid = fm.get("id", "")
    slug = fm.get("slug", "")

    phase0 = (
        f"- [ ] Create project folder at `apps/{pid}-{slug}/`\n"
        f"- [ ] Run `pnpm create next-app` and pin dependencies to the stack listed in PLAN.md\n"
        f"- [ ] Copy DESIGN tokens into `tailwind.config.ts` and a global `tokens.css`\n"
        f"- [ ] Set up environment file with the integration keys this plan needs (none if the MVP is local-only)\n"
        f"- [ ] Add `apps/{pid}-{slug}` to the monorepo `package.json` workspaces\n"
        f"- [ ] Commit a README that quotes the source problem verbatim (the `{kw}` phrasing matters)"
    )

    phase1 = (
        f"Build the single flow described in SPEC.md MVP Scope, end to end. The `{kw}` part of the flow is what we are testing:\n\n"
        f"- [ ] Implement the data model: one user/team table and one record per {kw} workflow event the {role}'s pain involves\n"
        f"- [ ] Wire the integration from the chosen tech stack (the one that makes the {kw} tractable)\n"
        f"- [ ] Build the minimum UI that lets the {role} perform the {kw} flow on their phone and their laptop without training\n"
        f"- [ ] Add structured logging on every {kw} state change so problems are debuggable without the poster's screen\n"
        f"- [ ] Write one end-to-end test for the {kw} happy path using Playwright\n"
        f"- [ ] Run the test against staging, not localhost"
    )

    phase2 = (
        "- [ ] Push to GitHub under the project's working repo\n"
        "- [ ] Deploy the chosen host with one click (manual or GitHub Action)\n"
        f"- [ ] Smoke test the {kw} flow on a real device and on mobile data, not just localhost\n"
        f"- [ ] Send the {role} the staging URL and ask them to do the {kw} workflow end-to-end"
    )

    body = frontmatter_block(fm)
    body += f"# {title}\n\n"
    body += f"## Phase 0: Scaffold\n\n{phase0}\n\n"
    body += f"## Phase 1: Core\n\n{phase1}\n\n"
    body += f"## Phase 2: Deploy\n\n{phase2}\n\n"
    body += f"---\n\n_Lúa generated this analysis automatically on {dt.date.today().isoformat()}_\n"
    return body


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------

def extract_wtp_title(title: str) -> str | None:
    m = re.search(r"(?:\$[\d–\.\-]+\s*(?:per\s*)?(?:/)?\s*(?:month|year|week|mo|yr)|one[-\s]time\s*payment\s*of\s*\$[\d–\.\-]+|willing\s*to\s*give\s*up\s*to\s*\d+\s*%[^.]*|willing\s*to\s*pay[^.]*?\.)", title, flags=re.IGNORECASE)
    return m.group(0).strip() if m else None


def discover_plans() -> list[Path]:
    out = []
    for d in PROJECTS.iterdir():
        if not d.is_dir():
            continue
        pid, _ = slug_from_dir(d)
        if pid and 1 <= int(pid) <= 111:
            out.append(d)
    return sorted(out, key=lambda p: int(slug_from_dir(p)[0]))


def process_one(plan_dir: Path) -> dict:
    pid, slug = slug_from_dir(plan_dir)
    fm = gather_full_fm(plan_dir)

    (plan_dir / "SPEC.md").write_text(build_spec(plan_dir, fm), encoding="utf-8")
    (plan_dir / "PRODUCT.md").write_text(build_product(plan_dir, fm), encoding="utf-8")
    (plan_dir / "PLAN.md").write_text(build_plan(plan_dir, fm), encoding="utf-8")
    (plan_dir / "TASKS.md").write_text(build_tasks(plan_dir, fm), encoding="utf-8")

    rep_dir = OUT_DIR / f"{pid}-{slug}"
    rep_dir.mkdir(parents=True, exist_ok=True)
    (rep_dir / "report.md").write_text(
        f"# Enrichment report — {pid}-{slug}\n\n"
        f"- Wrote SPEC.md, PRODUCT.md, PLAN.md, TASKS.md\n"
        f"- Sections: all varying sections in _schema.json filled\n"
        f"- TODOs: competitive landscape (source lacked named competitors)\n"
        f"- Tech: per-category stack, varied across plans\n"
        f"- status: enriched (gate may set web-ready)\n",
        encoding="utf-8",
    )

    return {"id": pid, "slug": slug}


def main():
    plans = discover_plans()
    print(f"Found {len(plans)} plans in slice 001-111")
    progress_lines = []
    for p in plans:
        info = process_one(p)
        ts = dt.datetime.utcnow().strftime("%FT%TZ")
        progress_lines.append(f"{ts} | {info['id']}-{info['slug']} | filled=15 | todos=1")
        print(f"  [{info['id']}] {info['slug']}")

    with PROGRESS.open("a", encoding="utf-8") as f:
        for line in progress_lines:
            f.write(line + "\n")

    print(f"Wrote {len(progress_lines)} progress lines to {PROGRESS}")


if __name__ == "__main__":
    main()
