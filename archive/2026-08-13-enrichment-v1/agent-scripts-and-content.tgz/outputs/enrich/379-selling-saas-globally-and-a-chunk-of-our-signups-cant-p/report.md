# 379 Selling saas globally and a chunk of our signups cant pay by card, anyone taking stablecoin and getting actual dollars out

sections filled: 13

sections left as TODO: 0

frontmatter changed: status draft -> enriched

check after enrichment:
```

ai-os plans check — 1 plan

  web-ready: 1/1 (100%)

  status: enriched=1 


```
