# 413 How to dissolve Delaware corp without paying a ton of fees? My company never did any actual business...I will not promote

sections filled: 13

sections left as TODO: 0

frontmatter changed: status draft -> enriched

check after enrichment:
```

ai-os plans check — 1 plan

  web-ready: 1/1 (100%)

  status: enriched=1 


```
