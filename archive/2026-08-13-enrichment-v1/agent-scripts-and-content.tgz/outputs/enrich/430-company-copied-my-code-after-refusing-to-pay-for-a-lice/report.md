# 430 Company copied my code after refusing to pay for a license. I know because their site is sending data to MY Hotjar account. What would you do?

sections filled: 13

sections left as TODO: 0

frontmatter changed: status draft -> enriched

check after enrichment:
```

ai-os plans check — 1 plan

  web-ready: 1/1 (100%)

  status: enriched=1 


```
