# 376 Ten years of getting good at building. I still don't know how to get anyone to care once it's built. (i will not promote)

sections filled: 13

sections left as TODO: 0

frontmatter changed: status draft -> enriched

check after enrichment:
```

ai-os plans check — 1 plan

  web-ready: 1/1 (100%)

  status: enriched=1 


```
