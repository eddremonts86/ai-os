# 388 Billing by the hour for bursty workloads was quietly killing us. Sleeping idle machines fixed the pricing, not just the bill

sections filled: 13

sections left as TODO: 0

frontmatter changed: status draft -> enriched

check after enrichment:
```

ai-os plans check — 1 plan

  web-ready: 1/1 (100%)

  status: enriched=1 


```
