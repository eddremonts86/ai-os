# 348 J'ai 15 ans et j'ai lancé un buisness tout à côté de mes études.

sections filled: 13

sections left as TODO: 0

frontmatter changed: status draft -> enriched

check after enrichment:
```

ai-os plans check — 1 plan

  web-ready: 1/1 (100%)

  status: enriched=1 


```
