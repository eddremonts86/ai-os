# 373 Built a sponsorship tool for creators. Have zero creators. How did you get the first side of a two-sided thing off the ground? I will not promote it, just blank on how to start.

sections filled: 13

sections left as TODO: 0

frontmatter changed: status draft -> enriched

check after enrichment:
```

ai-os plans check — 1 plan

  web-ready: 1/1 (100%)

  status: enriched=1 


```
